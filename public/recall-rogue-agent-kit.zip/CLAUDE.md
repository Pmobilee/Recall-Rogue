# Recall Rogue

Card roguelite where knowledge IS power. Svelte 5 + Phaser 3 + TypeScript. Quick Play cards for base effect, Charge them with quiz answers for massive multipliers, chain related facts for exponential damage.

## Build & Run
- `npm run dev` — Vite dev server on :5173
- `npm run build` — production build (Vite 7)
- `npm run typecheck` — TypeScript strict check
- `npm test` — Vitest suite
- `npm run build && npm run preview` — full production test

## Architecture (read docs/architecture.md for detail)
- **Game engine:** Phaser 3 (canvas/WebGL) for combat, sprites, VFX
- **UI framework:** Svelte 5 for overlays, menus, HUD, card hand
- **State:** Centralized `GameState` — all mutations through service methods
- **Entry:** `src/main.ts` → `CardApp.svelte` → `CardGameManager` (Phaser)
- **Game logic:** `src/game/` (scenes, systems, ECS) + `src/services/` (turn manager, FSRS, chain system)
- **UI components:** `src/ui/components/` (Svelte) — combat overlay, shop, reward screen, quiz panel
- **Card data:** `src/data/` — mechanics.ts, enemies.ts, relics.ts, balance.ts, chainTypes.ts
- **Deck content:** `data/decks/*.json` (curated decks), `public/facts.db` (trivia pool)
- **Assets:** `public/assets/` — sprites, backgrounds, audio, card frames

## Layout Modes
- Portrait (mobile, 390×844) — touch-first, fanned card arc
- Landscape (desktop, 1280×720) — keyboard+mouse, horizontal card row, split enemy panel
- Detected at runtime from viewport aspect ratio via `layoutStore.ts`
- Platform (mobile/desktop/web) is SEPARATE from layout mode

## Conventions
- All game state mutations go through service methods (turnManager, gameFlowController)
- Card effects are resolved through `cardEffectResolver.ts` damage pipeline (see docs/game-design.md §15.5)
- Pixel art: 16×16 base sprites, power-of-2 dimensions, ComfyUI + SDXL
- ZERO hardcoded px in CSS — use `calc(Npx * var(--layout-scale, 1))` and `--text-scale`
- Two layout modes must both work for any UI change
- All prices in gold (integer). All HP in integer. All multipliers can be float.
- Chain types use colors + icons (colorblind-safe, see chainIcons.ts)

## Key Docs (read before implementing)
- `docs/architecture.md` — module boundaries, data flow, file ownership
- `docs/game-design.md` — full GDD (single source of truth for game mechanics)
- `docs/gotchas.md` — things agents keep getting wrong
- `docs/plans/` — active feature specs (plan.md + context.md + tasks.md per feature)

## Chrome Lock Protocol
Before using Playwright or Claude-in-Chrome MCP:
1. `scripts/chrome-lock.sh status` — check if free
2. `scripts/chrome-lock.sh acquire <agent-name>` — claim lock
3. Do browser work
4. `scripts/chrome-lock.sh release` — always release when done
Lock auto-expires after 5 minutes. If locked, wait and retry — do NOT force-kill Chrome.

## When Compacting
Preserve: modified file list, current feature goal, failing test output, which agent owns which files.

## Agent Delegation (IMPORTANT)
You have specialized subagents. Delegate to them instead of doing everything yourself:
- Modifying `src/game/` or `src/services/` or `src/data/` → use **game-logic** agent
- Modifying `src/ui/` or any `.svelte` file or CSS → use **ui-agent**
- Modifying `data/decks/` or fact content → use **content-agent**
- Running tests, reviewing code, checking quality → use **qa-agent**
- Updating docs/, gotchas, architecture docs → use **docs-agent**

When a task spans multiple agents (e.g., "add a new card mechanic with UI"), delegate each part to the appropriate agent in parallel. Don't do it all yourself in one context.

The human can also invoke agents directly: "use game-logic agent to implement the chain fix" or "use qa-agent to review what I just did."

## Skill Routing
Skills are pre-loaded into agents via frontmatter. You can also invoke skills directly:

| Agent | Pre-loaded Skills |
|-------|-------------------|
| game-logic | headless-playtest, advanced-balance, balance-check, phaser-perf |
| ui-agent | visual-inspect, playthrough, frontend-design, artstudio |
| content-agent | deck-master, manual-fact-ingest-dedup, subcategorize, answer-checking |
| qa-agent | quick-verify, code-review, simplify, playtest-analyze, playtest-triage, playtest-results |
| docs-agent | game-design-sync, work-tracking |

Skills not assigned to agents (invoke directly):
- `/audio-manager` — sound system (180 synth sounds, BGM generation)
- `/mobile-debug` — Capacitor debugging
- `/android-deploy` — build and deploy APK
- `/site-manage` — recallrogue.com website
- `/llm-playtest` — LLM strategic playtesting
