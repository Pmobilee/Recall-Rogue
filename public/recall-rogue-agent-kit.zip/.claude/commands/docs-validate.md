---
description: Validate documentation accuracy by having a fresh agent predict code structure from docs alone, then check predictions against reality. The gold standard test for whether your docs are trustworthy.
---

# The Prediction Test

This command proves whether your docs are accurate enough for a fresh agent to work effectively.

**Step 1: Predict from docs only**

Read ONLY these files (do NOT read any source code yet):
- `CLAUDE.md`
- `docs/architecture.md`
- `docs/game-design.md` (just §1-§3 — core philosophy, card combat, chain system)

Based on these docs, predict:
1. What files exist in `src/services/` and what each one does
2. What the top-level folders in `src/` are
3. How the damage pipeline is ordered (which multipliers apply in which order)
4. What happens when a player charges a card (step by step, which files are involved)
5. What the chain multiplier values are

Write your predictions to a temporary file.

**Step 2: Check predictions against code**

Now read the actual code. For each prediction, compare:
- ✅ CORRECT — doc accurately described reality
- ⚠️ PARTIAL — doc was vaguely right but missing detail
- ❌ WRONG — doc said X, code does Y

**Step 3: Report**

```
## Docs Validation Report — [date]

### Prediction Accuracy: X/5 correct, Y/5 partial, Z/5 wrong

### Discrepancies Found
1. [doc says X, code does Y — which is correct?]
2. ...

### Missing from Docs
1. [important code behavior not documented anywhere]
2. ...

### Docs That Need Updating
1. [file] — [what section] — [what's wrong]
2. ...
```

If accuracy is 4/5+ correct, docs are trustworthy. If 3/5 or below, recommend running `/docs-rewrite`.
