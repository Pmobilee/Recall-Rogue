---
description: Bootstrap fresh documentation from the actual codebase. Use when existing docs are untrustworthy. Renames current docs/ to docs-old/, generates new docs from code, then prompts human to merge design intent from old docs.
---

# Phase 1: Quarantine old docs

Move existing documentation to a quarantine folder so new docs are generated without being influenced by potentially inaccurate old content.

```bash
if [ -d "docs" ]; then
  mv docs docs-old
  echo "Old docs quarantined to docs-old/"
fi
mkdir -p docs/plans docs/history/completed
```

# Phase 2: Generate fresh docs from code (5 parallel subagents)

Launch 5 parallel explore subagents. Each one reads ONLY the code — they must NOT read docs-old/.

**Subagent 1 — Architecture:**
Scan the entire `src/` directory tree. Map every folder's purpose, every major file's role, data flow between modules. Write `docs/architecture.md` containing:
- Folder-by-folder ownership map
- Service dependency graph (which services call which)
- Data flow: how a card play goes from user tap → Svelte component → service → Phaser → back to UI
- Key files list with one-line descriptions
Write ONLY what the code actually does. Not what it should do.

**Subagent 2 — Game mechanics snapshot:**
Read `src/data/mechanics.ts`, `src/data/enemies.ts`, `src/data/relics.ts`, `src/data/balance.ts`, `src/services/cardEffectResolver.ts`, `src/services/turnManager.ts`, `src/services/chainSystem.ts`. Extract:
- All active card mechanics with their actual values
- The actual damage pipeline steps
- Current balance constants
- Chain multiplier values
- Surge timing constants
Write to `docs/mechanics-snapshot.md`. This is a CODE TRUTH document — what the code actually computes.

**Subagent 3 — UI component map:**
Read all `src/ui/components/*.svelte` files. For each, document:
- Component name and purpose
- Key props and stores it consumes
- Which screen/flow it belongs to
- Layout behavior (portrait vs landscape differences if any)
Write to `docs/ui-components.md`.

**Subagent 4 — Test coverage:**
Read all `src/**/*.test.ts` files. Catalog:
- What is tested
- What is NOT tested (modules with no test file)
- Any skipped or failing tests
Write to `docs/test-coverage.md`.

**Subagent 5 — Tech debt and TODOs:**
Grep the entire codebase for: `TODO`, `FIXME`, `HACK`, `XXX`, `TEMP`, `@deprecated`.
Catalog each with file, line number, and surrounding context.
Write to `docs/tech-debt.md`.

# Phase 3: Update CLAUDE.md

After the subagents complete, read the new `docs/architecture.md` and update `CLAUDE.md` to reflect the actual project structure, build commands, and key doc references.

# Phase 4: Human merge step (DO NOT AUTO-EXECUTE)

Print the following instructions for the human:

```
=== DOCS REWRITE COMPLETE ===

Fresh docs generated from code:
  - docs/architecture.md      (module map from actual code)
  - docs/mechanics-snapshot.md (game values from actual code)
  - docs/ui-components.md      (Svelte component catalog)
  - docs/test-coverage.md      (what's tested, what isn't)
  - docs/tech-debt.md          (TODOs and FIXMEs)

Old docs quarantined in: docs-old/

YOUR NEXT STEPS:
1. Compare docs-old/game-design.md with docs/mechanics-snapshot.md
   - Mechanics-snapshot shows what the CODE does
   - Game-design shows what you INTENDED
   - Where they differ, decide: is the code wrong, or is the doc wrong?

2. Create docs/game-design.md by:
   - Starting with your existing GDD (docs-old/game-design.md)
   - Fixing any sections where the code diverged from the doc
   - Adding date comments on changed sections

3. Migrate docs-old/gotchas.md to docs/gotchas.md (keep ALL gotchas)

4. Migrate any active feature plans from docs-old/plans/ to docs/plans/

5. Once satisfied, delete docs-old/

Run /docs-validate after merging to verify consistency.
```
