---
description: Run at the end of every productive session. Updates gotchas, feature progress, and flags doc staleness. Takes 30 seconds.
---

# End-of-Session Maintenance

Do these three things quickly:

## 1. Gotchas Update
Review what happened this session. Did Claude (you) make any mistakes that should be recorded?

If yes, append to `docs/gotchas.md`:
```
### [Date] — [Brief description]
**What went wrong:** [what the agent did incorrectly]
**Why:** [root cause if known]
**Fix:** [what to do instead]
```

If no mistakes were made, skip this step.

## 2. Feature Progress
Check if there's an active plan in `docs/plans/`. If the session worked on a feature, update `tasks.md`:
- Check off completed tasks
- Add any new tasks discovered during implementation
- Note any blockers

## 3. Architecture Drift Check
If this session added new files, new services, or changed module boundaries:
- Flag that `docs/architecture.md` needs updating
- Print: "⚠️ Architecture may have drifted — run docs-agent to update docs/architecture.md"

## 4. Commit Summary
Print a brief summary of what was done this session, suitable for a git commit message:
```
[feature/fix/refactor]: [one-line description]

- [change 1]
- [change 2]
- [change 3]
```
