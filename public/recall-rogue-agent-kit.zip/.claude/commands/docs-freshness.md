---
description: Verify that docs match codebase reality. Run weekly or when docs feel stale.
---

Run 3 parallel subagents to check documentation freshness:

**Subagent 1 — Architecture check:**
Read `docs/architecture.md`. Then explore the actual `src/` folder structure using Glob. Compare: are all modules listed in the doc? Are the file ownership boundaries accurate? Are there new service files not mentioned? Report discrepancies.

**Subagent 2 — Build command check:**
Read the "Build & Run" section of `CLAUDE.md`. Execute each command listed:
- `npm run typecheck`
- `npm run build`
- `npm test`
Report any that fail or produce unexpected output.

**Subagent 3 — GDD spot-check:**
Read `docs/game-design.md` §2 (Card Combat) and §4 (Knowledge Surge). Then read `src/services/turnManager.ts` and `src/services/chainSystem.ts`. Check: do the constants in the code match the values documented in the GDD? Are any mechanics described in the GDD missing from code, or vice versa? Report discrepancies.

After all 3 subagents report, compile a summary:
```
## Docs Freshness Report — [date]

### Architecture: [PASS/STALE]
- [discrepancies if any]

### Build Commands: [PASS/BROKEN]
- [failures if any]

### GDD Spot-Check: [PASS/DRIFT]
- [mismatches if any]

### Action Items
- [numbered list of things to fix]
```

Do NOT auto-fix anything. Report findings for human review.
