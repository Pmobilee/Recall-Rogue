---
description: Plan a feature through an interview process. Produces a spec in docs/plans/ that a fresh session can execute. Use this for anything non-trivial.
---

# Feature Planning Interview

You are planning a feature for Recall Rogue. Your job is to interview the developer thoroughly, then write a complete spec.

## Interview Phase

Ask questions using the AskUserQuestion tool. Dig into:

1. **What exactly should change?** (Be specific — which screen, which mechanic, which numbers)
2. **What files are likely involved?** (Read docs/architecture.md if needed to identify the right modules)
3. **What are the edge cases?** (What happens on mobile vs desktop? What if the player has 0 gold? What if the deck is empty?)
4. **What should NOT change?** (Preserve existing behavior in X, don't touch Y)
5. **Does this affect both portrait and landscape?**
6. **Does this need new tests?**
7. **Does this change the GDD?** (If so, which sections need updating after implementation)

Keep interviewing until you've covered everything. Don't ask obvious questions — dig into the hard parts the developer might not have considered.

## Spec Phase

After the interview, create a feature plan folder:

```
docs/plans/YYYY-MM-DD-feature-name/
├── plan.md      — Full spec with context, changes, verification steps
├── context.md   — Key files involved, decisions made during planning
└── tasks.md     — Checklist of implementation tasks
```

### plan.md structure:
```markdown
# Feature Name

## Context
[Why this feature exists. What problem it solves.]

## Changes
[Numbered list of specific code changes with file paths and line references where possible]

## Verification
[How to confirm the implementation is correct — tests to run, visual checks, edge cases to verify]

## Files to Modify
[Bullet list of every file that needs changing]

## GDD Sections to Update
[Which sections of docs/game-design.md need updating after this ships]
```

### tasks.md structure:
```markdown
# Tasks — Feature Name

- [ ] Task 1 — [specific action, which file, what change]
- [ ] Task 2 — ...
- [ ] Typecheck passes
- [ ] Build passes
- [ ] Tests pass / new tests written
- [ ] Visual verification (portrait + landscape)
- [ ] GDD updated
- [ ] docs/gotchas.md updated if new gotchas discovered
```

## Final Instruction

After writing the spec, tell the developer:

"Spec written to docs/plans/[folder]. Start a FRESH SESSION (run /clear) and tell the new session: 'Read docs/plans/[folder]/plan.md and implement it.' The fresh context will execute better than continuing here."
