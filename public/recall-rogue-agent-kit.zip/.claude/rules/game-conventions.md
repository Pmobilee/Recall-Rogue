# Game Conventions

- All damage is integer (floor after all multipliers).
- Block absorbs before HP. Block resets to 0 each turn unless Fortify.
- Card effects resolve through the damage pipeline in cardEffectResolver.ts (see GDD §15.5). Never bypass it.
- Chain multipliers stack multiplicatively with charge multipliers, buff multipliers, and relic multipliers.
- Quick Play = 1.0× base. Charge Correct = 1.5× base + mastery bonus. Charge Wrong = 0.6-0.7× base.
- The +1 AP surcharge for Charging is waived during Surge turns and Chain Momentum.
- Surge occurs every 4th global turn (turns 2, 6, 10, 14...). Counter persists across encounters.
- Facts are assigned at charge-commit time, NOT at draw time. Cards in hand show mechanic + chain theme only.
- FSRS tiers (1/2a/2b/3) are for long-term knowledge tracking only. Combat power comes from card slot mastery (0-5).
- Card slot mastery resets each run. It is the primary power scaling axis.
- Two game modes: Trivia Dungeon (broad pool, no repeats) and Study Temple (curated deck, FSRS-weighted repetition).
- All vocabulary decks use generic chain types (Obsidian, Crimson, etc.). Knowledge decks use themed chains.
- Confusion matrix is persistent across runs. It drives distractor selection — each player's questions are unique.
- Never use the word "fizzle" for wrong answers in UI text. Wrong Charges still resolve (at 0.7×).
