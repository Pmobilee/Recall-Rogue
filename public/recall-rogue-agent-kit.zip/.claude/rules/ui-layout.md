# UI & Layout

- Every UI change must work in BOTH portrait and landscape. Test both before committing.
- Use `--layout-scale` for all dimensions: `calc(12px * var(--layout-scale, 1))`
- Use `--text-scale` for all font sizes: `calc(14px * var(--text-scale, 1))`
- Zero hardcoded px except: 1px borders, 0 values, Phaser canvas coords.
- Minimum tap target: 44×44px (iOS HIG).
- Svelte components own the overlay layer (card hand, quiz panel, HUD, shop, rewards).
- Phaser owns the canvas layer (enemy sprites, combat VFX, room backgrounds).
- The two layers communicate through services (turnManager, gameFlowController) — never direct calls.
- Card hand: fanned arc in portrait, horizontal flex-row in landscape.
- Quiz panel: slides in from bottom in portrait, occupies center-stage (left 70%) in landscape.
- Enemy panel: top 55% in portrait, right 30% in landscape. Always visible during quiz in landscape.
- Landscape keyboard shortcuts: 1-5 select cards, Q = Quick Play, E = Charge, 1-4 = quiz answers.
