# Testing

- Every card mechanic effect gets a unit test in its corresponding test file.
- Use Vitest. Run single tests during dev: `npx vitest run src/path/to/test.ts`
- Run full suite before committing: `npm test`
- Always typecheck after changes: `npm run typecheck`
- Build must pass: `npm run build` — check for Vite warnings too.
- For visual verification, use `/visual-inspect` or `/quick-verify` skill.
- Playwright screenshots: acquire Chrome lock first (see CLAUDE.md protocol).
- Test files live next to source: `src/services/chainSystem.ts` → `src/services/chainSystem.test.ts`
- Mock Phaser dependencies in unit tests. Don't import Phaser directly in service logic.
- Balance changes: run `/headless-playtest` after any mechanic value change.
