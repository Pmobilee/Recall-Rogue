# Code Style

- TypeScript strict mode. No `any` unless explicitly justified with a comment.
- ES modules (import/export). Never CommonJS (require).
- Destructure imports: `import { turnManager } from './services/turnManager'`
- Svelte 5 runes syntax: `$state`, `$derived`, `$effect`. No Svelte 4 stores for new code.
- Pure functions for game logic (cardEffectResolver, chainSystem, fsrs). Side effects only in services.
- File size target: 200-400 lines. 800 max. If a file exceeds 600 lines, consider splitting.
- Name files by feature/domain, not by type. `chainSystem.ts` not `utils.ts`.
- Prefer `const` over `let`. Never `var`.
- No default exports — always named exports.
- Error handling: never silently swallow errors. Log with context.
- Comments: explain WHY, not WHAT. The code should explain what.
