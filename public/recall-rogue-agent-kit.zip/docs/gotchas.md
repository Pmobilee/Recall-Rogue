# Gotchas — Things Agents Keep Getting Wrong

> APPEND ONLY. Never remove entries. Run `/session-end` to add new gotchas.
> This is the highest-signal document in the project. Every entry represents a real mistake that cost time.

---

### 2026-03-31 — Surge counter persists across encounters
**What went wrong:** Agent reset the surge counter at the start of each encounter.
**Why:** Intuitive assumption that per-encounter = fresh state. But surge uses a GLOBAL turn counter.
**Fix:** `RunState.globalTurnCounter` persists across encounters. `startEncounter()` receives it as the initial `turnNumber`. Only `encounterTurnNumber` (for enrage) is per-encounter.

### 2026-03-31 — chargeCorrectValue is dead data
**What went wrong:** Agent read `chargeCorrectValue` from mechanics.ts and used it for damage calculation.
**Why:** The field exists in the data but is NEVER read by the resolver.
**Fix:** Charge Correct is always computed as `quickPlayValue × CHARGE_CORRECT_MULTIPLIER` (1.5×). The `chargeCorrectValue` field is documentation only. Read `cardEffectResolver.ts` for the actual pipeline.

### 2026-03-31 — Facts are NOT assigned at draw time
**What went wrong:** Agent tried to display quiz content on cards in hand.
**Why:** Old v1/v2 behavior was to assign facts at draw time. v3 assigns at charge-commit time.
**Fix:** Cards in hand show: mechanic name, AP cost, chain theme color+icon+name, mastery level. NO question text, NO fact content, NO difficulty stars. Facts are selected by `selectFactForCharge()` only when the player commits to charging.

### 2026-03-31 — Layout changes must work in BOTH modes
**What went wrong:** Agent changed CSS in a Svelte component without testing landscape mode. Broke the quiz panel positioning.
**Why:** Single layout mode thinking. Most CSS changes affect both modes.
**Fix:** Every UI change must be verified in both 390×844 (portrait) and 1280×720 (landscape). Use `Ctrl+Shift+L` in dev to toggle.

### 2026-03-31 — No hardcoded px in CSS
**What went wrong:** Agent wrote `padding: 12px` instead of `calc(12px * var(--layout-scale, 1))`.
**Why:** Habit from normal web dev. Recall Rogue scales dynamically.
**Fix:** ALL dimensions use `--layout-scale`. ALL font sizes use `--text-scale`. Only exceptions: `1px` borders, `0` values, percentages, unitless values.

### 2026-03-31 — Chrome lock protocol
**What went wrong:** Agent tried to launch Playwright while another agent had Chrome open. Failed with "Opening in existing browser session" error.
**Why:** Playwright and Claude-in-Chrome MCP both try to control the same Chrome instance.
**Fix:** Always run `scripts/chrome-lock.sh status` before any browser work. Acquire lock, do work, release lock. See CLAUDE.md for full protocol.

### 2026-03-31 — Reward room item positions overflow cloth
**What went wrong:** Items spawned outside the cloth/rock area on the reward screen.
**Why:** `computeClothLayout` used `radiusX = (Math.random() * 0.42 + 0.05) * w` — items could reach 47% from center, exceeding the cloth edge at 50%.
**Fix:** Reduced scatter radius to 0.35 and added hard clamp so items never exceed cloth bounds with 30px margin for item size.

### 2026-03-31 — Wrong answer is 0.7×, NOT zero
**What went wrong:** Agent implemented wrong charge as a "fizzle" that did nothing.
**Why:** Common roguelike assumption that wrong = fail.
**Fix:** Wrong Charge ALWAYS resolves at 0.7× (mastery 1+) or 0.6× (mastery 0). The card is never wasted. The penalty is that 0.7× is worse than Quick Play's 1.0×, plus the wasted +1 AP surcharge.

### 2026-03-31 — Combo system is REMOVED
**What went wrong:** Agent referenced combo multipliers and ComboCounter.svelte.
**Why:** Combo existed in v1. It's been fully removed. Only chains remain.
**Fix:** Chain system only. `ChainCounter.svelte` replaces the old combo counter. No `COMBO_MULTIPLIERS`, no `comboCount`. Grep for "combo" and ignore anything you find — it's dead code or historical comments.
