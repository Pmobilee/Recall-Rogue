# Documentation Rewrite Strategy

> Read this before deciding how to handle your docs situation.

## Decision Framework

### Rewrite from scratch when:
- Docs describe a different game than what's in the code
- Architecture doc says "MVC" but the code is ECS
- GDD says cards cost mana but they actually cost AP
- The docs are fiction — they describe intent, not reality

### Overwrite incrementally when:
- Docs are roughly right but stale, incomplete, or messy
- Architecture is correct but missing the new shop system
- GDD has the right mechanics but outdated card lists
- The bones are good — the flesh needs updating

---

## Strategy A: Full Rewrite ("code is truth, docs are lies")

**When to use:** Your docs are so far from reality that an agent reading them would build the wrong thing.

### Step 1: Run `/docs-rewrite`
This command:
1. Moves `docs/` to `docs-old/` (quarantine)
2. Launches 5 parallel subagents to generate fresh docs from code only
3. Produces: architecture.md, mechanics-snapshot.md, ui-components.md, test-coverage.md, tech-debt.md
4. Updates CLAUDE.md

### Step 2: You merge design intent (HUMAN STEP)
The generated docs are accurate but soulless. They describe WHAT the code does, not WHY. You need to:
- Compare `docs-old/game-design.md` with `docs/mechanics-snapshot.md`
- Where they differ: decide if the code is wrong or the doc is wrong
- Pull "design philosophy" sections from the old GDD into the new docs
- Pull gotchas from `docs-old/gotchas.md` (keep ALL of them)
- Create the final `docs/game-design.md` by starting from your existing GDD and fixing inaccuracies

### Step 3: Validate
Run `/docs-validate` — a fresh agent predicts code structure from docs alone, then checks against reality. If 4/5+ predictions correct, your docs are trustworthy.

### Step 4: Clean up
Delete `docs-old/` once satisfied.

---

## Strategy B: Surgical Overwrite ("the bones are good")

**When to use:** Docs are mostly right but have drifted in specific areas.

### Step 1: Audit
```
"Read docs/architecture.md. Then explore the actual src/ folder structure.
Produce a DIFF: what does the doc say vs what the code actually does?
List every discrepancy. Don't fix anything yet — just report."
```

### Step 2: Fix discrepancies (fresh session)
```
"Read docs/architecture-audit.md (the discrepancy report).
Now update docs/architecture.md to match reality.
Preserve all design-intent sections (WHY decisions were made).
Only change factual inaccuracies (WHAT the code does)."
```

### Step 3: Fill gaps
```
"Read docs/game-design.md. List everything MISSING:
features that exist in code but aren't documented,
card effects not in the catalog,
shop mechanics not described.
Then add the missing sections."
```

---

## Keeping Docs Fresh (Ongoing)

### End-of-session ritual
Last prompt of every session: run `/session-end`. Updates gotchas, feature progress, and flags drift.

### Dedicated docs-agent
After every feature merge, run the docs-agent to update architecture.md and relevant GDD sections.

### Weekly freshness check
Run `/docs-freshness` — 3 parallel subagents verify docs match code reality.

### The golden rule
When Claude gets something wrong, don't just fix it — update `docs/gotchas.md` so the mistake never recurs. Gotchas are the highest-signal documentation in the entire project.

---

## Your GDD Specifically

Your game design document (docs/game-design.md) is ~40,000 words. Agents should NEVER read the whole thing in one session. Instead:

- **CLAUDE.md** references it as a path: "see docs/game-design.md"
- Agents read SPECIFIC SECTIONS when they need context for a task
- Section numbers are stable (§2 = Card Combat, §3 = Chain System, §7 = Run Structure, etc.)
- When updating the GDD, add a date comment: `> Updated 2026-04-01: changed X to Y`
- The GDD is the SINGLE SOURCE OF TRUTH for game design decisions. Code that conflicts with the GDD should be treated as a bug unless explicitly noted.
