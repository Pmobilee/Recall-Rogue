# Architecture — Recall Rogue

> This document describes the ACTUAL code structure. If it conflicts with what you expect, the code is truth.
> Last verified: [DATE — run /docs-validate to check freshness]

## High-Level Architecture

Two rendering layers, one state layer:

```
┌─────────────────────────────────────────────────┐
│  Svelte 5 Overlay Layer (src/ui/)               │
│  Card hand, quiz panel, HUD, shop, rewards,     │
│  menus, tooltips, transitions                   │
├─────────────────────────────────────────────────┤
│  Service Layer (src/services/)                  │
│  Game state, turn management, card resolution,  │
│  FSRS, chain system, encounter flow             │
├─────────────────────────────────────────────────┤
│  Phaser 3 Canvas Layer (src/game/)              │
│  Enemy sprites, combat VFX, room backgrounds,   │
│  parallax transitions, boot animation           │
└─────────────────────────────────────────────────┘
```

Svelte and Phaser NEVER call each other directly. They communicate through the service layer.

## Folder Ownership Map

| Folder | Owner Agent | Purpose |
|--------|-------------|---------|
| `src/game/` | game-logic | Phaser scenes, sprite systems, ECS, canvas VFX |
| `src/game/scenes/` | game-logic | CombatScene, RewardRoomScene, BootAnimScene, etc. |
| `src/game/systems/` | game-logic | EnemySpriteSystem, particle systems |
| `src/game/managers/` | game-logic | AudioManager (biome loops), CardGameManager |
| `src/services/` | game-logic | All game logic services (see Service Map below) |
| `src/ui/` | ui-agent | All Svelte components, stores, styles |
| `src/ui/components/` | ui-agent | CardHand, CardCombatOverlay, CardRewardScreen, ShopRoom, etc. |
| `src/ui/stores/` | ui-agent | layoutStore, playerData, reactive game state bindings |
| `src/data/` | game-logic + content | Static data definitions (mechanics, enemies, relics, balance, chains) |
| `data/decks/` | content-agent | Curated deck JSON files |
| `public/assets/` | — | Static assets (sprites, backgrounds, audio, card frames) |
| `public/facts.db` | content-agent | Trivia mode fact database |
| `docs/` | docs-agent | All documentation |
| `.claude/` | any (with care) | Agent definitions, commands, rules, skills |

## Service Map (src/services/)

> These are the core game logic services. Every game state mutation flows through one of these.

| Service | Purpose | Key Exports |
|---------|---------|-------------|
| `turnManager.ts` | Turn lifecycle, AP tracking, surge counter, enrage | `startPlayerTurn()`, `endPlayerTurn()`, `startEncounter()` |
| `cardEffectResolver.ts` | Damage pipeline (GDD §15.5), effect resolution | `resolveCardEffect()`, `computeDamage()` |
| `chainSystem.ts` | Chain state, multiplier calculation | `extendOrResetChain()`, `getChainMultiplier()` |
| `gameFlowController.ts` | Screen transitions, encounter flow, reward flow | `advanceEncounter()`, `openCardReward()`, `openShop()` |
| `encounterBridge.ts` | Bridge between Phaser combat and Svelte UI | `onEncounterComplete()`, accuracy grade calculation |
| `runPoolBuilder.ts` | Builds the card pool for a run from selected deck | `buildRunPool()` |
| `audioService.ts` | Web Audio API synthesis (180+ sounds) | `playSound()`, `playCue()` |
| `cardAudioManager.ts` | High-level audio cue mapping | `playCardCue()` |
| `fsrs.ts` | FSRS algorithm integration (ts-fsrs) | `updateFactState()`, `getReviewPriority()` |
| `platformService.ts` | Platform detection (mobile/desktop/web) | `platform`, `isDesktop`, `isMobile` |
| `inputService.ts` | Semantic input dispatch (keyboard/touch) | `subscribe()`, `setQuizVisible()` |
| `keyboardInput.ts` | Keyboard bindings (landscape only) | Auto-binds in landscape mode |
| `entitlementService.ts` | Content gating (free vs paid) | `hasDomainAccess()` |
| `characterLevel.ts` | XP, leveling, mechanic unlock schedule | `processXPGain()`, `getUnlockedMechanics()` |
| `knowledgeAuraSystem.ts` | Brain Fog gauge (0-10) | `adjustAura()`, `getAuraState()` |
| `reviewQueueSystem.ts` | Per-encounter wrong-answer review queue | `addToReviewQueue()`, `isReviewQueueFact()` |
| `accuracyGradeSystem.ts` | Post-encounter accuracy grade (S/A/B/C) | `calculateAccuracyGrade()` |
| `ascension.ts` | Ascension mode modifiers (levels 1-20) | `getAscensionModifiers()` |

## Data Flow: Card Play (Charge Correct)

```
1. Player drags card above 40% threshold in CardHand.svelte
2. CardCombatOverlay.svelte detects release in charge zone
3. selectFactForCharge() in services picks a fact from the chain theme pool
4. Quiz panel (CardExpanded.svelte) appears with question + distractors
5. Player answers correctly
6. cardEffectResolver.resolveCardEffect() runs the damage pipeline:
   → base value + mastery bonus + inscription bonus + relic flat
   → × effectMultiplier × chainMultiplier × speedBonus × buffMultiplier × relicPercent × overclock
   → + burn + bleed + relic post-multiply flat
   → × vulnerable
   → block absorbs → HP damage
7. turnManager updates AP, mastery, chain state, FSRS, confusion matrix
8. CombatScene (Phaser) plays VFX — particles, screen shake, damage numbers
9. encounterBridge checks win/loss conditions
```

## Layout Modes

| Aspect | Portrait (mobile) | Landscape (desktop) |
|--------|-------------------|---------------------|
| Canvas | 390×844 | 1280×720 |
| Card hand | Bottom 42%, fanned arc | Bottom 26vh, horizontal flex-row |
| Enemy | Top 55%, centered | Right 30%, always visible |
| Quiz panel | Slides up from bottom | Center-stage (left 70%) |
| HUD | Compact mobile layout | Spread across top bar |
| Input | Touch + gestures | Mouse + keyboard shortcuts |

Detected at runtime by viewport aspect ratio. `layoutStore.ts` drives all reactive branching.
