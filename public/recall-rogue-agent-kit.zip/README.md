# Recall Rogue — Agent Kit

Drop these files into your project root. Everything is customized for your game's architecture.

## What's Included

```
CLAUDE.md                              ← Boot screen (<2k tokens, loaded every session)
.claude/
├── rules/
│   ├── code-style.md                  ← Auto-loaded: TypeScript/Svelte conventions
│   ├── game-conventions.md            ← Auto-loaded: damage pipeline, chains, FSRS, mastery
│   ├── testing.md                     ← Auto-loaded: test framework, verification steps
│   └── ui-layout.md                   ← Auto-loaded: portrait/landscape rules, CSS scaling
├── agents/
│   ├── game-logic.md                  ← Owns: src/game/, src/services/, src/data/
│   ├── ui-agent.md                    ← Owns: src/ui/ (all Svelte components, CSS, animations)
│   ├── content-agent.md               ← Owns: data/decks/, vocabulary templates, fact quality
│   ├── qa-agent.md                    ← Reviews: code quality, tests, visual correctness, balance
│   └── docs-agent.md                  ← Maintains: all docs/, CLAUDE.md, gotchas
├── commands/
│   ├── feature-plan.md                ← Interview → spec → fresh session execute pattern
│   ├── docs-rewrite.md                ← Nuclear option: bootstrap fresh docs from code
│   ├── docs-validate.md               ← Prediction test: can a fresh agent navigate from docs alone?
│   ├── docs-freshness.md              ← Weekly check: do docs still match code?
│   └── session-end.md                 ← End-of-session: update gotchas, progress, flag drift
docs/
├── architecture.md                    ← Module boundaries, service map, data flow
├── gotchas.md                         ← Living record of agent mistakes (APPEND ONLY)
├── rewrite-strategy.md                ← How to decide: full rewrite vs surgical overwrite
├── game-design.md                     ← YOUR GDD (paste your existing one here)
└── plans/                             ← Active feature specs (one folder per feature)
```

## Setup Steps

1. Copy all files into your Recall Rogue project root
2. Paste your existing GDD as `docs/game-design.md` (the one you just shared)
3. Run `/docs-validate` to test if your docs are accurate enough
4. If accuracy is low, run `/docs-rewrite` to bootstrap fresh docs from code
5. If accuracy is high, run `/docs-freshness` to patch any small discrepancies

## Daily Workflow

**Morning:** Fresh session → read yesterday's `docs/plans/` spec → execute feature → `/session-end`
**Midday:** Launch qa-agent in parallel to review morning's work → start next `/feature-plan`
**Afternoon:** Execute afternoon spec in fresh session → `/session-end`
**End of day:** Run docs-agent to update architecture docs → commit everything

## Multi-Agent Parallel Setup

Use git worktrees so agents work on separate branches without conflicts:

```bash
# Create worktrees for parallel agents
git worktree add ../recall-rogue-ui -b feature/ui-work
git worktree add ../recall-rogue-logic -b feature/logic-work

# Run game-logic agent in one terminal
cd ../recall-rogue-logic && claude

# Run ui-agent in another terminal
cd ../recall-rogue-ui && claude

# QA agent reviews both before merge
```

## Key Rule: Agent File Ownership

No two agents should ever edit the same file. If they need to coordinate:
- game-logic writes the service API → ui-agent reads it for component props
- ui-agent writes the component → qa-agent reviews it
- content-agent writes deck data → game-logic reads it for pool building
- docs-agent reads everything, writes only docs/

## Chrome Lock Protocol

Only one agent can use the browser at a time. All agents must follow the lock protocol in CLAUDE.md:
```bash
scripts/chrome-lock.sh status     # Check if free
scripts/chrome-lock.sh acquire X  # Claim for agent X
scripts/chrome-lock.sh release    # Release when done
```
